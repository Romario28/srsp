package com.entreprise.gestion.config;

import com.entreprise.gestion.entite.*;
import com.entreprise.gestion.repository.*;
import com.entreprise.gestion.service.DepartementService;
import com.entreprise.gestion.service.PorteeService;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

/**
 * Initialise la base H2 avec une hiérarchie complète à 5 niveaux (thème MEF, voir
 * cahier des charges), démontrant chaque mécanisme de portée :
 *
 *   Secrétariat Général
 *   └─ Direction Générale des Impôts (DGI)
 *      └─ Direction du Contrôle Fiscal (DCF)
 *         └─ Service des Vérifications
 *            └─ Division A (2 agents + 1 chef)
 *   └─ Direction Générale du Budget (DGB)         [2e branche, pour comparer]
 *
 * Démontre : chef structurel à chaque niveau, RH_CENTRAL (voit tout), RH_LOCAL
 * délégué sur DCF (voit DCF + Service + Division A, sans être chef nulle part),
 * et le repli "soi-même" pour un agent standard sans délégation.
 *
 * ⚠️ Remplace l'ancien seed plat (EMP001-4, groupes IT/RH) : Employe.departement
 * est maintenant obligatoire, incompatible avec l'ancienne donnée sans département.
 */
@Component
@RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {

    private final RoleRepository            roleRepository;
    private final PermissionRepository      permissionRepository;
    private final DepartementRepository     departementRepository;
    private final EmployeRepository         employeRepository;
    private final UtilisateurRepository     utilisateurRepository;
    private final UtilisateurRoleRepository utilisateurRoleRepository;
    private final PasswordEncoder           passwordEncoder;
    private final DepartementService        departementService;
    private final PorteeService             porteeService;

    @Override
    @Transactional
    public void run(String... args) {

        // ══════════════════════════════════════════════════════════════
        // 1. PERMISSIONS
        // ══════════════════════════════════════════════════════════════
        Permission pRead   = save(perm("EMPLOYE_READ",   "Consulter la liste des employés"));
        Permission pWrite  = save(perm("EMPLOYE_WRITE",  "Créer et modifier un employé"));
        Permission pDelete = save(perm("EMPLOYE_DELETE", "Supprimer un employé"));
        Permission pUser   = save(perm("USER_MANAGE",    "Gérer les comptes utilisateurs"));
        Permission pAudit  = save(perm("AUDIT_READ",     "Consulter le journal d'audit"));

        // ══════════════════════════════════════════════════════════════
        // 2. RÔLES
        // ══════════════════════════════════════════════════════════════
        Role roleEmploye = roleRepository.save(withPerms(
                Role.builder().nomRole("ROLE_EMPLOYE")
                        .description("Employé standard — voit son sous-arbre s'il est chef, sinon lui-même")
                        .build(),
                pRead));

        Role roleManager = roleRepository.save(withPerms(
                Role.builder().nomRole("ROLE_MANAGER")
                        .description("Capacité d'écriture — la portée réelle reste dérivée de la structure")
                        .build(),
                pRead, pWrite));

        Role roleRhCentral = roleRepository.save(withPerms(
                Role.builder().nomRole("ROLE_RH_CENTRAL")
                        .description("RH central — voit tout l'organigramme, comme ADMIN mais sans droits système")
                        .build(),
                pRead, pWrite));

        Role roleRhLocal = roleRepository.save(withPerms(
                Role.builder().nomRole("ROLE_RH_LOCAL")
                        .description("RH local — portée définie par une PorteeDeleguee (DG/Direction/Service uniquement)")
                        .build(),
                pRead, pWrite));

        Role roleAdmin = roleRepository.save(withPerms(
                Role.builder().nomRole("ROLE_ADMIN")
                        .description("Administrateur — accès complet, y compris comptes et sécurité")
                        .build(),
                pRead, pWrite, pDelete, pUser, pAudit));

        // ══════════════════════════════════════════════════════════════
        // 3. HIÉRARCHIE — départements créés SANS chef d'abord (dépendance
        //    circulaire Departement ↔ Employe, voir Departement.java)
        // ══════════════════════════════════════════════════════════════
        Departement sg = departementService.creer(Departement.builder()
                .nomDepartement("Secrétariat Général")
                .niveau(NiveauDepartement.SECRETARIAT_GENERAL)
                .build());

        Departement dgi = departementService.creer(Departement.builder()
                .nomDepartement("Direction Générale des Impôts")
                .niveau(NiveauDepartement.DIRECTION_GENERALE)
                .departementParent(sg)
                .build());

        Departement dgb = departementService.creer(Departement.builder()
                .nomDepartement("Direction Générale du Budget")
                .niveau(NiveauDepartement.DIRECTION_GENERALE)
                .departementParent(sg)
                .build());

        Departement dcf = departementService.creer(Departement.builder()
                .nomDepartement("Direction du Contrôle Fiscal")
                .niveau(NiveauDepartement.DIRECTION)
                .departementParent(dgi)
                .build());

        Departement serviceVerif = departementService.creer(Departement.builder()
                .nomDepartement("Service des Vérifications")
                .niveau(NiveauDepartement.SERVICE)
                .departementParent(dcf)
                .build());

        Departement divisionA = departementService.creer(Departement.builder()
                .nomDepartement("Division A — Vérifications Entreprises")
                .niveau(NiveauDepartement.DIVISION)
                .departementParent(serviceVerif)
                .build());

        // ══════════════════════════════════════════════════════════════
        // 4. EMPLOYÉS — rattachés à leur département (obligatoire désormais)
        // ══════════════════════════════════════════════════════════════
        Employe empSg  = employeRepository.save(employe("MEF001", "Rasoanaivo", "Voahangy",
                "Secrétaire Générale", sg, LocalDate.of(2015, 1, 12)));
        Employe empDgi = employeRepository.save(employe("MEF002", "Andriamampianina", "Tojo",
                "Directeur Général des Impôts", dgi, LocalDate.of(2017, 3, 4)));
        Employe empDgb = employeRepository.save(employe("MEF003", "Rasolofoson", "Herimanana",
                "Directeur Général du Budget", dgb, LocalDate.of(2018, 6, 20)));
        Employe empDcf = employeRepository.save(employe("MEF004", "Rakotomalala", "Nirina",
                "Directeur du Contrôle Fiscal", dcf, LocalDate.of(2019, 2, 15)));
        Employe empSv  = employeRepository.save(employe("MEF005", "Razafindrakoto", "Hery",
                "Chef du Service des Vérifications", serviceVerif, LocalDate.of(2020, 4, 1)));
        Employe empDva = employeRepository.save(employe("MEF006", "Ravelojaona", "Miora",
                "Chef de Division A", divisionA, LocalDate.of(2021, 5, 10)));
        Employe empAgent1 = employeRepository.save(employe("MEF007", "Rabemanantsoa", "Fanja",
                "Agent vérificateur", divisionA, LocalDate.of(2022, 9, 1)));
        Employe empAgent2 = employeRepository.save(employe("MEF008", "Randriamanana", "Solo",
                "Agent vérificateur", divisionA, LocalDate.of(2023, 1, 16)));
        Employe empRh = employeRepository.save(employe("MEF009", "Rabarison", "Vonjy",
                "Responsable RH Central", sg, LocalDate.of(2016, 8, 3)));

        // ══════════════════════════════════════════════════════════════
        // 5. AFFECTATION DES CHEFS — maintenant que les employés existent
        // ══════════════════════════════════════════════════════════════
        assignerChef(sg, empSg);
        assignerChef(dgi, empDgi);
        assignerChef(dgb, empDgb);
        assignerChef(dcf, empDcf);
        assignerChef(serviceVerif, empSv);
        assignerChef(divisionA, empDva);

        // ══════════════════════════════════════════════════════════════
        // 6. COMPTES UTILISATEURS
        // ══════════════════════════════════════════════════════════════
        Utilisateur admin = utilisateurRepository.save(Utilisateur.builder()
                .email("admin@entreprise.mg")
                .motDePasseHash(passwordEncoder.encode("Admin123!"))
                .statut(StatutUtilisateur.ACTIF)
                .build());
        assignRole(admin, roleAdmin);

        Utilisateur uSg = compte("voahangy.rasoanaivo@entreprise.mg", "Chef123!", empSg, roleEmploye);
        Utilisateur uDgi = compte("tojo.andriamampianina@entreprise.mg", "Chef123!", empDgi, roleEmploye);
        Utilisateur uDgb = compte("herimanana.rasolofoson@entreprise.mg", "Chef123!", empDgb, roleEmploye);
        Utilisateur uDcf = compte("nirina.rakotomalala@entreprise.mg", "Chef123!", empDcf, roleEmploye);
        Utilisateur uSv = compte("hery.razafindrakoto@entreprise.mg", "Chef123!", empSv, roleEmploye);
        Utilisateur uDva = compte("miora.ravelojaona@entreprise.mg", "Chef123!", empDva, roleEmploye);
        Utilisateur uAgent1 = compte("fanja.rabemanantsoa@entreprise.mg", "Employe123!", empAgent1, roleEmploye);
        Utilisateur uAgent2 = compte("solo.randriamanana@entreprise.mg", "Employe123!", empAgent2, roleEmploye);
        Utilisateur uRh = compte("vonjy.rabarison@entreprise.mg", "RhCentral123!", empRh, roleRhCentral);

        // ══════════════════════════════════════════════════════════════
        // 7. DÉMONSTRATION RH LOCAL — Fanja (agent, PAS chef) reçoit une
        //    délégation RH sur la Direction du Contrôle Fiscal entier.
        //    Elle verra donc DCF + Service + Division A malgré n'être chef
        //    de rien — la preuve que la délégation ajoute réellement de la portée.
        // ══════════════════════════════════════════════════════════════
        porteeService.accorderRoleRHLocal(uAgent1, dcf, admin, LocalDate.now(), null);
        assignRole(uAgent1, roleRhLocal);

        // ══════════════════════════════════════════════════════════════
        // 8. COMPTE SUPER-ADMIN DE SECOURS (compte système protégé)
        // ══════════════════════════════════════════════════════════════
        String motDePasseSecours = System.getenv()
                .getOrDefault("SUPERADMIN_PASSWORD", "SuperSecret_ChangeMe_2024!");
        Utilisateur superAdmin = utilisateurRepository.save(Utilisateur.builder()
                .email("superadmin@entreprise.mg")
                .motDePasseHash(passwordEncoder.encode(motDePasseSecours))
                .statut(StatutUtilisateur.ACTIF)
                .compteSysteme(true)
                .build());
        assignRole(superAdmin, roleAdmin);

        // ══════════════════════════════════════════════════════════════
        // Résumé console
        // ══════════════════════════════════════════════════════════════
        System.out.println("\n╔═══════════════════════════════════════════════════════════════════╗");
        System.out.println("║              Hiérarchie MEF initialisée — comptes de test           ║");
        System.out.println("╠═══════════════════════════════════════════════════════════════════╣");
        System.out.println("║ admin@entreprise.mg                Admin123!      ROLE_ADMIN        ║");
        System.out.println("║ vonjy.rabarison@entreprise.mg      RhCentral123!  ROLE_RH_CENTRAL   ║");
        System.out.println("║                                     → voit TOUT l'organigramme       ║");
        System.out.println("║ nirina.rakotomalala@entreprise.mg  Chef123!       chef de DCF        ║");
        System.out.println("║                                     → voit DCF + Service + Division  ║");
        System.out.println("║ fanja.rabemanantsoa@entreprise.mg  Employe123!    agent + RH_LOCAL   ║");
        System.out.println("║                                     → délégation sur DCF (pas chef)  ║");
        System.out.println("║ solo.randriamanana@entreprise.mg   Employe123!    agent standard     ║");
        System.out.println("║                                     → ne voit QUE lui-même            ║");
        System.out.println("╠═══════════════════════════════════════════════════════════════════╣");
        System.out.println("║  H2 Console : http://localhost:8080/h2-console                      ║");
        System.out.println("╚═══════════════════════════════════════════════════════════════════╝\n");
    }

    // ── Helpers privés ────────────────────────────────────────────────────────

    private Permission perm(String nom, String desc) {
        return Permission.builder().nomPermission(nom).description(desc).build();
    }

    private Permission save(Permission p) {
        return permissionRepository.save(p);
    }

    private Role withPerms(Role role, Permission... permissions) {
        for (Permission p : permissions) role.getPermissions().add(p);
        return role;
    }

    private Employe employe(String matricule, String nom, String prenom, String poste,
                            Departement departement, LocalDate dateEmbauche) {
        return Employe.builder()
                .matricule(matricule).nom(nom).prenom(prenom).poste(poste)
                .departement(departement).dateEmbauche(dateEmbauche)
                .build();
    }

    private void assignerChef(Departement d, Employe chef) {
        d.setChef(chef);
        departementRepository.save(d);
    }

    private Utilisateur compte(String email, String motDePasse, Employe employe, Role role) {
        Utilisateur u = utilisateurRepository.save(Utilisateur.builder()
                .email(email)
                .motDePasseHash(passwordEncoder.encode(motDePasse))
                .statut(StatutUtilisateur.ACTIF)
                .employe(employe)
                .build());
        assignRole(u, role);
        return u;
    }

    private void assignRole(Utilisateur utilisateur, Role role) {
        UtilisateurRole ur = UtilisateurRole.builder()
                .utilisateur(utilisateur)
                .role(role)
                .build();
        utilisateurRoleRepository.save(ur);
    }
}
