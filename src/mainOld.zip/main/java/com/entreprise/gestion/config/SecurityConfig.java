package com.entreprise.gestion.config;

import com.entreprise.gestion.security.JwtAuthFilter;
import com.entreprise.gestion.security.UserDetailsServiceImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.List;

/**
 * ⚠️ CHANGEMENT : ROLE_RH_CENTRAL et ROLE_RH_LOCAL ajoutés aux routes /api/employes
 * (au même niveau que MANAGER — leur portée réelle est affinée par PorteeService,
 * pas ici). /api/utilisateurs, /api/groupes et /api/audit restent ADMIN uniquement :
 * le cahier des charges ne demande une visibilité élargie que sur les employés.
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity
@RequiredArgsConstructor
public class SecurityConfig {

    private final JwtAuthFilter jwtAuthFilter;
    private final UserDetailsServiceImpl userDetailsService;

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .cors(cors -> cors.configurationSource(corsConfigurationSource()))
                .sessionManagement(sess -> sess
                        .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth

                        .requestMatchers("/api/auth/login").permitAll()
                        .requestMatchers("/h2-console/**").permitAll()

                        // ── Employés ─────────────────────────────────────────────────
                        // POST/PUT : authenticated() volontairement, PAS hasAnyRole(...).
                        // Un chef structurel (Departement.chef) peut n'avoir QUE ROLE_EMPLOYE
                        // en Spring Security — sa capacité d'écriture est dérivée de la
                        // structure, pas d'un rôle assigné. La exiger ici bloquerait un chef
                        // légitime avant même que PorteeService.estModifiable() ne s'exécute.
                        // L'autorisation fine reste entièrement à la charge du service.
                        .requestMatchers(HttpMethod.GET,
                                "/api/employes", "/api/employes/**")
                        .hasAnyRole("ADMIN", "MANAGER", "EMPLOYE", "RH_CENTRAL", "RH_LOCAL")
                        .requestMatchers(HttpMethod.POST, "/api/employes")
                        .authenticated()
                        .requestMatchers(HttpMethod.PUT, "/api/employes/**")
                        .authenticated()
                        .requestMatchers(HttpMethod.DELETE, "/api/employes/**")
                        .hasRole("ADMIN")

                        // ── Utilisateurs, groupes, départements, audit : ADMIN uniquement ──
                        // (Le cahier des charges élargit la portée sur les employés, pas
                        //  sur la gestion des comptes système ou de la structure elle-même.)
                        .requestMatchers("/api/utilisateurs/**").hasRole("ADMIN")
                        .requestMatchers("/api/groupes/**").hasRole("ADMIN")
                        .requestMatchers("/api/departements/**").hasRole("ADMIN")
                        .requestMatchers("/api/audit/**").hasRole("ADMIN")

                        .anyRequest().authenticated()
                )
                .headers(h -> h.frameOptions(f -> f.disable()))
                .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration config = new CorsConfiguration();
        config.setAllowedOrigins(List.of("http://localhost:5173"));
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"));
        config.setAllowedHeaders(List.of("*"));
        config.setAllowCredentials(true);
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", config);
        return source;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config)
            throws Exception {
        return config.getAuthenticationManager();
    }
}
