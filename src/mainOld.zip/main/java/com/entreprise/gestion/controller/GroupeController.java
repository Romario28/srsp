package com.entreprise.gestion.controller;

import com.entreprise.gestion.entite.Groupe;
import com.entreprise.gestion.repository.GroupeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/groupes")
@RequiredArgsConstructor
@PreAuthorize("hasRole('ADMIN')")
public class GroupeController {

    private final GroupeRepository groupeRepository;

    @GetMapping
    public ResponseEntity<List<Groupe>> getAll() {
        return ResponseEntity.ok(groupeRepository.findAll());
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Groupe groupe) {
        try {
            return ResponseEntity.status(HttpStatus.CREATED)
                .body(groupeRepository.save(groupe));
        } catch (Exception e) {
            return ResponseEntity.badRequest()
                .body(Map.of("error", "Nom de groupe déjà utilisé"));
        }
    }
}
