package com.entreprise.gestion.controller;

import com.entreprise.gestion.dto.CreateEmployeRequest;
import com.entreprise.gestion.dto.EmployeResponse;
import com.entreprise.gestion.dto.UpdateEmployeRequest;
import com.entreprise.gestion.security.UserDetailsImpl;
import com.entreprise.gestion.service.AuditService;
import com.entreprise.gestion.service.EmployeService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employes")
@RequiredArgsConstructor
public class EmployeController {

    private final EmployeService employeService;
    private final AuditService   auditService;

    /*@GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','EMPLOYE')")
    public ResponseEntity<List<EmployeResponse>> getAll() {
        return ResponseEntity.ok(employeService.findAll());
    }
*/
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','EMPLOYE','RH','RH_LOCAL')")
    public ResponseEntity<List<EmployeResponse>> getAll(@AuthenticationPrincipal UserDetailsImpl principal) {
        return ResponseEntity.ok(employeService.findAllVisiblesPar(principal));
    }
    /*@GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','EMPLOYE')")
    public ResponseEntity<EmployeResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(employeService.findById(id));
    }*/


    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','EMPLOYE','RH','RH_LOCAL')")
    public ResponseEntity<EmployeResponse> getById(@PathVariable Long id,
                                                   @AuthenticationPrincipal UserDetailsImpl principal) {
        return ResponseEntity.ok(employeService.findByIdPour(id, principal));
    }

    /*@GetMapping("/departement/{dept}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<List<EmployeResponse>> getByDepartement(@PathVariable String dept) {
        return ResponseEntity.ok(employeService.findByDepartement(dept));
    }*/
/*
    @GetMapping("/departement/{idDepartement}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','RH','RH_LOCAL')")
    public ResponseEntity<List<EmployeResponse>> getByDepartement(@PathVariable Long idDepartement) {
        return ResponseEntity.ok(employeService.findByDepartement(idDepartement));
    }*/

    @GetMapping("/departement/{idDepartement}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','EMPLOYE','RH_CENTRAL','RH_LOCAL')")
    public ResponseEntity<List<EmployeResponse>> getByDepartement(
            @PathVariable Long idDepartement,
            @AuthenticationPrincipal UserDetailsImpl principal) {
        return ResponseEntity.ok(employeService.findByDepartement(idDepartement, principal.getUtilisateur()));
    }

    /*@PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<?> create1(
            @Valid @RequestBody CreateEmployeRequest req,   // ← @Valid ajouté
            @AuthenticationPrincipal UserDetailsImpl principal) {
        try {
            EmployeResponse saved = employeService.create(req);
            auditService.logAvecEntite(
                    principal.getUtilisateur(),
                    "CREATE_EMPLOYE",
                    "Matricule : " + saved.getMatricule() + " par " + principal.getNomComplet(),
                    null
            );
            return ResponseEntity.status(HttpStatus.CREATED).body(saved);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }*/

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<EmployeResponse> create(
            @Valid @RequestBody CreateEmployeRequest req,
            @AuthenticationPrincipal UserDetailsImpl principal) {

        EmployeResponse saved = employeService.create(req);
        auditService.logAvecEntite(
                principal.getUtilisateur(),
                "CREATE_EMPLOYE",
                "Matricule : " + saved.getMatricule() + " par " + principal.getNomComplet(),
                null
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
        // Plus de try/catch : BusinessException remonte vers GlobalExceptionHandler
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','RH','RH_LOCAL')")
    public ResponseEntity<EmployeResponse> update(
            @PathVariable Long id,
            @Valid @RequestBody UpdateEmployeRequest req,
            @AuthenticationPrincipal UserDetailsImpl principal) {
        EmployeResponse saved = employeService.update(id, req, principal);
        auditService.logAvecEntite(principal.getUtilisateur(), "UPDATE_EMPLOYE",
                "Id : " + id + " par " + principal.getNomComplet(), null);
        return ResponseEntity.ok(saved);
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Void> delete(@PathVariable Long id, @AuthenticationPrincipal UserDetailsImpl principal) {
        employeService.delete(id);
        auditService.logAvecEntite(principal.getUtilisateur(), "DELETE_EMPLOYE",
                "Id : " + id + " par " + principal.getNomComplet(), null);
        return ResponseEntity.noContent().build();
    }

  /*  @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER')")
    public ResponseEntity<?> update(
            @PathVariable Long id,
            @Valid @RequestBody UpdateEmployeRequest req,   // ← @Valid ajouté
            @AuthenticationPrincipal UserDetailsImpl principal) {
        try {
            EmployeResponse saved = employeService.update(id, req);
            auditService.logAvecEntite(
                    principal.getUtilisateur(),
                    "UPDATE_EMPLOYE",
                    "Id : " + id + " — " + saved.getNom() + " " + saved.getPrenom()
                            + " par " + principal.getNomComplet(),
                    null
            );
            return ResponseEntity.ok(saved);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> delete(
            @PathVariable Long id,
            @AuthenticationPrincipal UserDetailsImpl principal) {
        try {
            employeService.delete(id);
            auditService.logAvecEntite(
                    principal.getUtilisateur(),
                    "DELETE_EMPLOYE",
                    "Id : " + id + " par " + principal.getNomComplet(),
                    null
            );
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }*/


}