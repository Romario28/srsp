package com.entreprise.gestion.entite;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.HashSet;
import java.util.Set;

/**
 * Groupe organisationnel (ex: IT, RH, Finance).
 * Un utilisateur appartient à zéro ou un groupe.
 */
@Entity
@Table(name = "groupe",schema = "gestion_utilisateurs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Groupe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_groupe")
    private Long id;

    @NotNull
    @Size(max = 100)
    @Column(name = "nom_groupe", nullable = false, unique = true, length = 100)
    private String nomGroupe;


    @Column(name = "description", length = 255, columnDefinition = "text")
    private String description;

    /**
     * Relation inverse : Utilisateur porte la FK id_groupe.
     * JsonIgnore pour casser la boucle Groupe → Utilisateur → Groupe.
     */
    @JsonIgnore
    @OneToMany(mappedBy = "groupe", fetch = FetchType.LAZY)
    @Builder.Default
    private Set<Utilisateur> utilisateurs = new HashSet<>();
}
