package com.entreprise.gestion.entite;

/** Non mappé JPA — utilisé uniquement par AutoriteService. */
public enum CapaciteRH { LECTURE, MODIFICATION_GENERALE, MODIFICATION_RH }