package com.entreprise.gestion.entite;

public enum NiveauDepartement {
    SECRETARIAT_GENERAL(1),
    DIRECTION_GENERALE(2),
    DIRECTION(3),
    SERVICE(4),
    DIVISION(5);

    private final int ordre;
    NiveauDepartement(int ordre) { this.ordre = ordre; }
    public int getOrdre() { return ordre; }
}