package com.entreprise.gestion.service;

import com.entreprise.gestion.dto.CreateUtilisateurRequest;
import com.entreprise.gestion.dto.UtilisateurDTO;
import com.entreprise.gestion.entite.*;
import com.entreprise.gestion.exception.BusinessException;
import com.entreprise.gestion.repository.*;
import com.entreprise.gestion.security.UserDetailsImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

/**
 * MIGRATION UserDetailsImpl :

 * Les méthodes create() et changeStatut() reçoivent maintenant un UserDetailsImpl
 * au lieu d'un simple String email. Cela permet d'appeler auditService.logAvecEntite()
 * directement depuis le service — zéro findByEmail() supplémentaire.
 */
@Service
@RequiredArgsConstructor
public class UtilisateurService {

    private final UtilisateurRepository     utilisateurRepository;
    private final EmployeRepository         employeRepository;
    private final GroupeRepository          groupeRepository;
    private final RoleRepository            roleRepository;
    private final UtilisateurRoleRepository utilisateurRoleRepository;
    private final PasswordEncoder           passwordEncoder;
    private final AuditService              auditService;

    @Transactional(readOnly = true)
    public List<UtilisateurDTO> findAll() {
        return utilisateurRepository.findAllWithRelations()
                .stream().map(this::toDTO).collect(Collectors.toList());
    }



    @Transactional(readOnly = true)
    public UtilisateurDTO findById(Long id) {
        Utilisateur u = utilisateurRepository.findById(id)
                .orElseThrow(() -> new BusinessException(
                        "UTILISATEUR_INTROUVABLE", "Utilisateur introuvable : " + id));

        if (u.isCompteSysteme()) {
            // On ne révèle pas l'existence du compte : même erreur que "introuvable"
            throw new BusinessException(
                    "UTILISATEUR_INTROUVABLE", "Utilisateur introuvable : " + id);
        }
        return toDTO(u);
    }

    /**
     * AVANT : create(CreateUtilisateurRequest req, String actorEmail)
     * APRÈS : create(CreateUtilisateurRequest req, UserDetailsImpl actor)

     * L'entité admin est directement disponible — logAvecEntite() sans requête BDD.
     */
    @Transactional
    public Utilisateur create(CreateUtilisateurRequest req,
                              UserDetailsImpl actor) {

        if (utilisateurRepository.existsByEmail(req.getEmail())) {
            throw new RuntimeException("Email déjà utilisé : " + req.getEmail());
        }

        Utilisateur utilisateur = Utilisateur.builder()
                .email(req.getEmail())
                .motDePasseHash(passwordEncoder.encode(req.getPassword()))
                .statut(StatutUtilisateur.ACTIF)
                .build();

        if (req.getIdEmploye() != null) {
            Employe employe = employeRepository.findById(req.getIdEmploye())
                    .orElseThrow(() ->
                            new RuntimeException("Employé introuvable : " + req.getIdEmploye()));
            if (employeRepository.hasUtilisateur(req.getIdEmploye())) {
                throw new RuntimeException(
                        "Cet employé possède déjà un compte utilisateur.");
            }
            utilisateur.setEmploye(employe);
        }

        if (req.getIdGroupe() != null) {
            groupeRepository.findById(req.getIdGroupe())
                    .ifPresent(utilisateur::setGroupe);
        }

        List<String> rolesNames = (req.getRoles() != null && !req.getRoles().isEmpty())
                ? req.getRoles()
                : List.of("ROLE_EMPLOYE");

        Utilisateur saved = utilisateurRepository.save(utilisateur);

        for (String nomRole : rolesNames) {
            Role role = roleRepository.findByNomRole(nomRole)
                    .orElseThrow(() ->
                            new RuntimeException("Rôle inconnu : " + nomRole));
            utilisateurRoleRepository.save(
                    UtilisateurRole.builder()
                            .utilisateur(saved)
                            .role(role)
                            .build()
            );
        }

        // Log avec l'entité admin directement disponible
        auditService.logAvecEntite(
                actor.getUtilisateur(),
                "CREATE_USER",
                "Créé : " + saved.getEmail()
                        + " (rôles : " + String.join(", ", rolesNames) + ")"
                        + " par " + actor.getNomComplet(),
                null
        );

        return saved;
    }

    /**
     * AVANT : changeStatut(Long id, String statut, String actorEmail)
     * APRÈS : changeStatut(Long id, String statut, UserDetailsImpl actor)
     */

    /* *
    @Transactional
    public Utilisateur changeStatutAncien(Long id, String statut, UserDetailsImpl actor) {
        StatutUtilisateur nouveauStatut;
        try {
            nouveauStatut = StatutUtilisateur.valueOf(statut);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Statut invalide : " + statut);
        }

        if (id.equals(actor.getId())) {
            throw new RuntimeException("Vous ne pouvez pas modifier votre propre statut.");
        }


        Utilisateur utilisateur = utilisateurRepository.findById(id)
                .orElseThrow(() ->
                        new RuntimeException("Utilisateur introuvable : " + id));

        String ancienn = utilisateur.getStatut().name();
        utilisateur.setStatut(nouveauStatut);
        Utilisateur saved = utilisateurRepository.save(utilisateur);

        auditService.logAvecEntite(
                actor.getUtilisateur(),
                "CHANGE_STATUT",
                utilisateur.getEmail() + " : " + ancienn + " → " + statut
                        + " par " + actor.getNomComplet(),
                null
        );

        return saved;
    }
*/

    @Transactional
    public Utilisateur changeStatut(Long id, String statut, UserDetailsImpl actor) {

        StatutUtilisateur nouveauStatut;
        try {
            nouveauStatut = StatutUtilisateur.valueOf(statut);
        } catch (IllegalArgumentException e) {
            throw new BusinessException("STATUT_INVALIDE", "Statut invalide : " + statut);
        }

        Utilisateur utilisateur = utilisateurRepository.findById(id)
                .orElseThrow(() -> new BusinessException(
                        "UTILISATEUR_INTROUVABLE", "Utilisateur introuvable : " + id));

        // ── Garde 1 : compte système — jamais modifiable via l'API ─────────────
        if (utilisateur.isCompteSysteme()) {
            throw new BusinessException("COMPTE_PROTEGE",
                    "Ce compte est protégé et ne peut pas être modifié via l'API.");
        }

        boolean passeEnNonActif = nouveauStatut != StatutUtilisateur.ACTIF;

        // ── Garde 2 : un utilisateur ne peut pas changer son propre statut ─────
        //    (empêche notamment un admin de se suspendre lui-même)
        if (passeEnNonActif && utilisateur.getId().equals(actor.getId())) {
            throw new BusinessException("AUTO_SUSPENSION_INTERDITE",
                    "Vous ne pouvez pas suspendre ou désactiver votre propre compte.");
        }

        // ── Garde 3 : impossible de suspendre le dernier admin actif ───────────
        boolean estAdmin = utilisateur.getRoles().stream()
                .anyMatch(r -> "ROLE_ADMIN".equals(r.getNomRole()));

        if (estAdmin && passeEnNonActif && utilisateur.getStatut() == StatutUtilisateur.ACTIF) {
            long adminsActifs = utilisateurRepository
                    .countByRoleAndStatutExcludingSysteme("ROLE_ADMIN", StatutUtilisateur.ACTIF);
            if (adminsActifs <= 1) {
                throw new BusinessException("DERNIER_ADMIN",
                        "Impossible de suspendre le dernier administrateur actif.");
            }
        }

        String ancien = utilisateur.getStatut().name();
        utilisateur.setStatut(nouveauStatut);
        Utilisateur saved = utilisateurRepository.save(utilisateur);

        auditService.logAvecEntite(
                actor.getUtilisateur(),
                "CHANGE_STATUT",
                utilisateur.getEmail() + " : " + ancien + " → " + statut
                        + " par " + actor.getNomComplet(),
                null
        );

        return saved;
    }



    // ── Mapper entité → DTO ──────────────────────────────────────────────────

    private UtilisateurDTO toDTO(Utilisateur u) {
        UtilisateurDTO dto = new UtilisateurDTO();
        dto.setId(u.getId());
        dto.setEmail(u.getEmail());
        dto.setStatut(u.getStatut().name());
        dto.setDateCreation(u.getDateCreation());
        dto.setDateDerniereConnexion(u.getDateDerniereConnexion());
        if (u.getGroupe() != null)
            dto.setNomGroupe(u.getGroupe().getNomGroupe());
        if (u.getEmploye() != null) {
            dto.setNomEmploye(
                    u.getEmploye().getPrenom() + " " + u.getEmploye().getNom());
            dto.setMatriculeEmploye(u.getEmploye().getMatricule());
        }
        dto.setRoles(u.getUtilisateurRoles().stream()
                .map(ur -> ur.getRole().getNomRole())
                .collect(Collectors.toList()));
        return dto;
    }
}
