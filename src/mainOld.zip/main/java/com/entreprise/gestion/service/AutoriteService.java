package com.entreprise.gestion.service;

import com.entreprise.gestion.entite.CapaciteRH;
import com.entreprise.gestion.entite.Employe;
import com.entreprise.gestion.repository.DepartementRepository;
import com.entreprise.gestion.repository.PorteeDelegueeRepository;
import com.entreprise.gestion.security.UserDetailsImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AutoriteService {

    private final DepartementRepository departementRepository;
    private final PorteeDelegueeRepository porteeRepository;

    @Transactional(readOnly = true)
    public void verifierCapacite(UserDetailsImpl viewer, Employe cible, CapaciteRH capacite) {
        if (!aCapacite(viewer, cible, capacite)) {
            throw new AccessDeniedException("Droits " + capacite + " requis sur cet employé.");
        }
    }

    @Transactional(readOnly = true)
    public boolean aCapacite(UserDetailsImpl viewer, Employe cible, CapaciteRH capacite) {
        if (viewer.hasRole("ADMIN")) return true;
        if (viewer.hasRole("RH"))    return true;

        String cheminCible = cible.getDepartement().getChemin();
        Employe viewerEmploye = viewer.getEmploye();

        boolean estChef = viewerEmploye != null &&
                departementRepository.findByChefId(viewerEmploye.getId())
                        .map(d -> cheminCible.startsWith(d.getChemin()))
                        .orElse(false);

        boolean estRhLocal = viewer.hasRole("RH_LOCAL") && viewerEmploye != null &&
                cheminCible.startsWith(viewerEmploye.getDepartement().getChemin());

        LocalDate aujourdhui = LocalDate.now();
        boolean delegueLecture  = porteeRepository.existeDelegationLecture(viewer.getId(), cheminCible, aujourdhui);
        boolean delegueEcriture = porteeRepository.existeDelegationEcriture(viewer.getId(), cheminCible, aujourdhui);

        return switch (capacite) {
            case LECTURE               -> estChef || estRhLocal || delegueLecture;
            case MODIFICATION_GENERALE -> estChef || delegueEcriture;
            case MODIFICATION_RH       -> estRhLocal || (delegueEcriture && viewer.hasRole("RH_LOCAL"));
        };
    }

    @Transactional(readOnly = true)
    public boolean voitTout(UserDetailsImpl viewer) {
        return viewer.hasRole("ADMIN") || viewer.hasRole("RH");
    }

    @Transactional(readOnly = true)
    public List<String> getCheminsAutorises(UserDetailsImpl viewer) {
        List<String> chemins = new ArrayList<>();
        Employe viewerEmploye = viewer.getEmploye();
        if (viewerEmploye != null) {
            departementRepository.findByChefId(viewerEmploye.getId())
                    .ifPresent(d -> chemins.add(d.getChemin()));
            if (viewer.hasRole("RH_LOCAL")) {
                chemins.add(viewerEmploye.getDepartement().getChemin());
            }
        }
        chemins.addAll(porteeRepository.findCheminsDeleguesActifs(viewer.getId(), LocalDate.now()));
        return chemins;
    }
}