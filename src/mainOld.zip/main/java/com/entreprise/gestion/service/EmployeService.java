package com.entreprise.gestion.service;

import com.entreprise.gestion.dto.CreateEmployeRequest;
import com.entreprise.gestion.dto.EmployeResponse;
import com.entreprise.gestion.dto.UpdateEmployeRequest;
import com.entreprise.gestion.entite.CapaciteRH;
import com.entreprise.gestion.entite.Departement;
import com.entreprise.gestion.entite.Employe;
import com.entreprise.gestion.exception.BusinessException;
import com.entreprise.gestion.repository.DepartementRepository;
import com.entreprise.gestion.repository.EmployeRepository;
import com.entreprise.gestion.security.UserDetailsImpl;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class EmployeService {

    private final EmployeRepository employeRepository;
    private final DepartementRepository departementRepository;
    private final AutoriteService autoriteService;

    @Transactional(readOnly = true)
    public List<EmployeResponse> findAllVisiblesPar(UserDetailsImpl viewer) {
        Set<Long> idsAvecCompte = employeRepository.findIdsWithUtilisateur();
        List<Employe> employes = employeRepository.findAllWithDepartement();

        if (!autoriteService.voitTout(viewer)) {
            List<String> chemins = autoriteService.getCheminsAutorises(viewer);
            employes = employes.stream()
                    .filter(e -> chemins.stream().anyMatch(c -> e.getDepartement().getChemin().startsWith(c)))
                    .collect(Collectors.toList());
        }

        return employes.stream()
                .map(e -> {
                    EmployeResponse dto = EmployeResponse.from(e);
                    dto.setAUnCompte(idsAvecCompte.contains(e.getId()));
                    return dto;
                })
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public EmployeResponse findByIdPour(Long id, UserDetailsImpl viewer) {
        Employe e = employeRepository.findByIdWithDepartement(id)
                .orElseThrow(() -> new BusinessException("EMPLOYE_INTROUVABLE", "Employé introuvable : " + id));
        autoriteService.verifierCapacite(viewer, e, CapaciteRH.LECTURE);
        return EmployeResponse.from(e);
    }

    @Transactional(readOnly = true)
    public List<EmployeResponse> findByDepartement(Long idDepartement) {
        return employeRepository.findByDepartementId(idDepartement).stream()
                .map(EmployeResponse::from)
                .collect(Collectors.toList());
    }

    @Transactional
    public EmployeResponse create(CreateEmployeRequest req) {
        if (employeRepository.existsByMatricule(req.getMatricule())) {
            throw new BusinessException("MATRICULE_EXISTANT", "Matricule déjà utilisé : " + req.getMatricule());
        }
        Departement departement = departementRepository.findById(req.getIdDepartement())
                .orElseThrow(() -> new BusinessException("DEPARTEMENT_INTROUVABLE",
                        "Département introuvable : " + req.getIdDepartement()));

        Employe employe = Employe.builder()
                .matricule(req.getMatricule()).nom(req.getNom()).prenom(req.getPrenom())
                .poste(req.getPoste()).departement(departement)
                .dateEmbauche(req.getDateEmbauche()).build();

        return EmployeResponse.from(employeRepository.save(employe));
    }

    @Transactional
    public EmployeResponse update(Long id, UpdateEmployeRequest req, UserDetailsImpl viewer) {
        Employe employe = findEntityById(id);
        autoriteService.verifierCapacite(viewer, employe, CapaciteRH.MODIFICATION_GENERALE);

        if (req.getNom()          != null) employe.setNom(req.getNom());
        if (req.getPrenom()       != null) employe.setPrenom(req.getPrenom());
        if (req.getPoste()        != null) employe.setPoste(req.getPoste());
        if (req.getDateEmbauche() != null) employe.setDateEmbauche(req.getDateEmbauche());

        // Correctif : la version précédente laissait ce champ totalement ignoré
        if (req.getIdDepartement() != null) {
            employe.setDepartement(departementRepository.findById(req.getIdDepartement())
                    .orElseThrow(() -> new BusinessException("DEPARTEMENT_INTROUVABLE",
                            "Département introuvable : " + req.getIdDepartement())));
        }
        return EmployeResponse.from(employeRepository.save(employe));
    }

    @Transactional
    public void delete(Long id) {
        Employe employe = findEntityById(id);
        if (employeRepository.hasUtilisateur(id)) {
            throw new BusinessException("COMPTE_LIE", "Impossible : cet employé possède un compte. Désactivez-le d'abord.");
        }
        employeRepository.deleteById(id);
    }

    public Employe findEntityById(Long id) {
        return employeRepository.findById(id)
                .orElseThrow(() -> new BusinessException("EMPLOYE_INTROUVABLE", "Employé introuvable : " + id));
    }

    @Transactional(readOnly = true)
    public Optional<Employe> getSuperieurHierarchique(Long employeId) {
        Employe employe = findEntityById(employeId);
        Departement depart = employe.getDepartement();

        boolean estChefDeSonDepartement = depart.getChef() != null
                && depart.getChef().getId().equals(employe.getId());
        depart = estChefDeSonDepartement ? depart.getDepartementParent() : depart;

        while (depart != null && depart.getChef() == null) {
            depart = depart.getDepartementParent();
        }
        return Optional.ofNullable(depart).map(Departement::getChef);
    }
}