package com.entreprise.gestion.service;

import com.entreprise.gestion.entite.Departement;
import com.entreprise.gestion.entite.NiveauDepartement;
import com.entreprise.gestion.exception.BusinessException;
import com.entreprise.gestion.repository.DepartementRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class DepartementService {

    private final DepartementRepository departementRepository;

    @Transactional
    public Departement creer(String nom, String description, NiveauDepartement niveau, Long idParent) {
        Departement parent = null;
        if (idParent != null) {
            parent = departementRepository.findById(idParent)
                    .orElseThrow(() -> new BusinessException(
                            "DEPARTEMENT_INTROUVABLE", "Département parent introuvable"));
            validerNiveau(niveau, parent.getNiveau());
        } else if (niveau != NiveauDepartement.SECRETARIAT_GENERAL) {
            throw new BusinessException("PARENT_REQUIS", "Seul un Secrétariat Général peut être racine.");
        }

        Departement saved = departementRepository.save(Departement.builder()
                .nomDepartement(nom).description(description)
                .niveau(niveau).departementParent(parent).chemin("/").build());

        saved.setChemin((parent != null ? parent.getChemin() : "/") + saved.getId() + "/");
        return departementRepository.save(saved);
    }

    private void validerNiveau(NiveauDepartement enfant, NiveauDepartement parent) {
        if (enfant.getOrdre() != parent.getOrdre() + 1) {
            throw new BusinessException("NIVEAU_INVALIDE",
                    enfant + " doit avoir pour parent le niveau juste au-dessus.");
        }
    }
}