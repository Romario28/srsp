package com.entreprise.gestion.dto;

import com.entreprise.gestion.entite.Employe;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDate;

@Data
@Builder
public class EmployeResponse {

    private Long      id;
    private String    matricule;
    private String    nom;
    private String    prenom;
    private String    poste;
    private Long    idDepartement;
    private String    nomDepartement;
    private LocalDate dateEmbauche;
    private boolean   aUnCompte;   // utile pour le frontend (icône / badge)

    public static EmployeResponse from(Employe e) {
        return EmployeResponse.builder()
                .id(e.getId())
                .matricule(e.getMatricule())
                .nom(e.getNom())
                .prenom(e.getPrenom())
                .poste(e.getPoste())
                .idDepartement(e.getDepartement().getId())
                .nomDepartement(e.getDepartement().getNomDepartement())
                .dateEmbauche(e.getDateEmbauche())
                // utilisateur est LAZY : on ne le touche pas ici
                // la valeur est renseignée par le service qui sait si la session est ouverte
                .aUnCompte(false)
                .build();
    }
}