package com.entreprise.gestion.repository;

import com.entreprise.gestion.entite.Groupe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface GroupeRepository extends JpaRepository<Groupe, Long> {
    Optional<Groupe> findByNomGroupe(String nomGroupe);
}
