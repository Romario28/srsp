package com.entreprise.gestion.repository;

import com.entreprise.gestion.entite.Departement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface DepartementRepository extends JpaRepository<Departement, Long> {

    Optional<Departement> findByNomDepartement(String nomDepartement);
    Optional<Departement> findByChefId(Long chefId);   // unique=true → au plus un résultat
    List<Departement> findByDepartementParentId(Long parentId);
    List<Departement> findByCheminStartingWith(String chemin);

//    @Query("SELECT d FROM Departement d WHERE d.chemin LIKE CONCAT(:chemin, '%')")
//    List<Departement> findSousArbre(String chemin);
//
//    @Query("SELECT d FROM Departement d WHERE d.chemin LIKE CONCAT(:ancienChemin, '%') AND d.id <> :id")
//    List<Departement> findDescendantsStricts(String ancienChemin, Long id);

//2

    boolean existsByNomDepartement(String nomDepartement);
    List<Departement> findByDepartementParentIsNull();

}