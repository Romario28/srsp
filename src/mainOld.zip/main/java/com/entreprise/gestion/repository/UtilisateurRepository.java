package com.entreprise.gestion.repository;

import com.entreprise.gestion.entite.StatutUtilisateur;
import com.entreprise.gestion.entite.Utilisateur;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UtilisateurRepository extends JpaRepository<Utilisateur, Long> {

    Optional<Utilisateur> findByEmail(String email);

    boolean existsByEmail(String email);

    List<Utilisateur> findByStatut(StatutUtilisateur statut);

    // Charger l'utilisateur avec ses rôles en une seule requête (évite N+1)
    @Query("SELECT u FROM Utilisateur u " +
            "LEFT JOIN FETCH u.utilisateurRoles ur " +
            "LEFT JOIN FETCH ur.role " +
            "WHERE u.email = :email")
    Optional<Utilisateur> findByEmailWithRoles(String email);

    @Query("SELECT DISTINCT u FROM Utilisateur u " +
            " LEFT JOIN FETCH u.groupe " +
            "LEFT JOIN FETCH u.employe " +
            "LEFT JOIN FETCH u.utilisateurRoles ur " +
            "LEFT JOIN FETCH ur.role")
    List<Utilisateur> findAllWithRelations();
/*
    // APRÈS — charge tout ce dont UserDetailsImpl a besoin
    @Query("SELECT u FROM Utilisateur u " +
            "LEFT JOIN FETCH u.utilisateurRoles ur " +
            "LEFT JOIN FETCH ur.role " +
            "LEFT JOIN FETCH u.groupe " +
            "LEFT JOIN FETCH u.employe " +
            "WHERE u.email = :email")
    Optional<Utilisateur> findByEmailWithRolesAndRelations(String email);*/

    @Query("SELECT u FROM Utilisateur u " +
            "LEFT JOIN FETCH u.utilisateurRoles ur " +
            "LEFT JOIN FETCH ur.role " +
            "LEFT JOIN FETCH u.groupe " +
            "LEFT JOIN FETCH u.employe e " +
            "LEFT JOIN FETCH e.departement " +   // ← toujours manquant, obligatoire pour RH_LOCAL
            "WHERE u.email = :email")
    Optional<Utilisateur> findByEmailWithRolesAndRelations(String email);

    @Query("SELECT u FROM Utilisateur u " +
            "LEFT JOIN FETCH u.utilisateurRoles ur " +
            "LEFT JOIN FETCH ur.role r " +
            "LEFT JOIN FETCH r.permissions " +  // ← ajout
            "LEFT JOIN FETCH u.employe " +       // ← ajout
            "LEFT JOIN FETCH u.groupe " +        // ← ajout
            "WHERE u.email = :email")
    Optional<Utilisateur> findByEmailWithRolesAndPermissions(String email);


    /**
     * Compte les utilisateurs actifs possédant un rôle donné, en excluant
     * les comptes système. Le super-admin de secours ne doit jamais
     * "compter" pour débloquer la suspension d'un admin visible — sinon
     * la règle métier perdrait tout son sens protecteur.
     */
    @Query("SELECT COUNT(DISTINCT u) FROM Utilisateur u " +
            "JOIN u.utilisateurRoles ur JOIN ur.role r " +
            "WHERE r.nomRole = :nomRole AND u.statut = :statut AND u.compteSysteme = false")
    long countByRoleAndStatutExcludingSysteme(@Param("nomRole") String nomRole,
                                              @Param("statut") StatutUtilisateur statut);



}
