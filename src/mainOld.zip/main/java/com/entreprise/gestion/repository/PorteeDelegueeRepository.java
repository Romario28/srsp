package com.entreprise.gestion.repository;

import com.entreprise.gestion.entite.PorteeDeleguee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;

public interface PorteeDelegueeRepository extends JpaRepository<PorteeDeleguee, Long> {
    List<PorteeDeleguee> findByUtilisateurId(Long utilisateurId);

    List<PorteeDeleguee> findByUtilisateurIdOrderByDateDebutDesc(Long utilisateurId);

    List<PorteeDeleguee> findByDepartementId(Long idDepartement);
/*
    @Query("SELECT COUNT(p) > 0 FROM PorteeDeleguee p " +
            "WHERE p.utilisateur.id = :viewerId " +
            "AND :cheminCible LIKE CONCAT(p.departement.chemin, '%') " +
            "AND p.dateDebut <= :aujourdhui " +
            "AND (p.dateFin IS NULL OR p.dateFin >= :aujourdhui)")
    boolean existeDelegationLecture(@Param("viewerId") Long viewerId,
                                    @Param("cheminCible") String cheminCible,
                                    @Param("aujourdhui") LocalDate aujourdhui);

    @Query("SELECT COUNT(p) > 0 FROM PorteeDeleguee p " +
            "WHERE p.utilisateur.id = :viewerId " +
            "AND :cheminCible LIKE CONCAT(p.departement.chemin, '%') " +
            "AND p.typeAcces = com.entreprise.gestion.entite.TypeAcces.LECTURE_ECRITURE " +
            "AND p.dateDebut <= :aujourdhui " +
            "AND (p.dateFin IS NULL OR p.dateFin >= :aujourdhui)")
    boolean existeDelegationEcriture(@Param("viewerId") Long viewerId,
                                     @Param("cheminCible") String cheminCible,
                                     @Param("aujourdhui") LocalDate aujourdhui);

    @Query("SELECT p.departement.chemin FROM PorteeDeleguee p " +
            "WHERE p.utilisateur.id = :viewerId " +
            "AND p.dateDebut <= :aujourdhui " +
            "AND (p.dateFin IS NULL OR p.dateFin >= :aujourdhui)")
    List<String> findCheminsDeleguesActifs(@Param("viewerId") Long viewerId,
                                           @Param("aujourdhui") LocalDate aujourdhui);*/
}
